create PROCEDURE emp_count
  (p_deptno    IN  NUMBER default 20, -- 프로시저 입력 변수
   o_emp_count OUT NUMBER)               -- 프로시저 출력 변수
IS
  -- 커서 선언
  CURSOR get_emp_data IS
    SELECT COUNT(*)
    FROM emp
    WHERE deptno = p_deptno;
  l_count NUMBER;
  BEGIN
    -- 커서 오픈
    OPEN get_emp_data;

    -- 커서 FETCH
    FETCH get_emp_data INTO l_count;

    -- 출력 변수에 값 입력
    -- 선언되지 않은 변수를 사용
    o_employee_count := l_count;

    -- 커서 CLOSE
    CLOSE get_emp_data;
  END emp_count;
/

