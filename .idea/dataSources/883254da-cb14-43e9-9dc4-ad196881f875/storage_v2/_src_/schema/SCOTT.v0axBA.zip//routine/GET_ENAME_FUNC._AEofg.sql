create FUNCTION get_ename_func(p_empno IN NUMBER)
  RETURN VARCHAR2
IS

  -- 명시적 커서 선언
  CURSOR c1 IS
    SELECT ename
    FROM emp
    WHERE empno = p_empno;

  -- 추출 칼럼과 같은 타입의 변수 선언
  l_ename emp.ename%TYPE;

  BEGIN

    -- 커서 오픈
    OPEN c1;

    -- 데이터 추출 후 INTO절 안의 변수에 입력
    FETCH c1 INTO l_ename;

    -- 추출 결과 건수가 0일 경우
    IF c1%NOTFOUND
    THEN
      l_ename := NULL;
    END IF;

    -- 커서 닫기
    CLOSE c1;

    RETURN l_ename;
  END;
/

