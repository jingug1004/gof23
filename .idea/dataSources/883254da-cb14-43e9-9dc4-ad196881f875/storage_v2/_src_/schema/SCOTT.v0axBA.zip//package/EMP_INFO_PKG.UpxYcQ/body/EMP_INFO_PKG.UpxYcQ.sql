create PACKAGE BODY emp_info_pkg AS

  -- 패키지 명세에서 선언한 함수 내용
  -- 사원 정보 조회 함수
  FUNCTION get_ename_func(p_empno NUMBER)
    -- 리턴될 타입 선언
    RETURN emprectyp
  IS
    l_emprec emprectyp;
    BEGIN

      -- 암묵적 커서 선언하여 emprectyp 레코드 타입 변수에 결과 저장
      SELECT empno, ename, sal
          INTO l_emprec FROM emp WHERE empno = p_empno;

      -- 함수가 호출될 때마다 전역변수의 값이 1씩 증가
      g_hired_cnt := g_hired_cnt + 1;

      -- 사원 이름 반환
      RETURN l_emprec;
    END get_ename_func;

  -- 패키지 명세에서 선언한 프로시저 내용
  -- 부서 정보 조회 함수
  PROCEDURE get_dname_proc(p_deptno IN NUMBER, p_dname OUT VARCHAR2)
  IS
    BEGIN

      -- 부서 이름 저장
      SELECT dname
          INTO p_dname FROM dept WHERE deptno = p_deptno;
    END get_dname_proc;

  -- 패키지 내부에서만 사용 가능한 함수 선언
  -- salary의 등급이 적정한지 여부 확인하여 Boolean 타입 반환
  FUNCTION sal_ok_func(p_grade NUMBER, p_salary NUMBER)
    RETURN BOOLEAN IS
    l_min_sal NUMBER;
    l_max_sal NUMBER;
    BEGIN
      SELECT losal, hisal
          INTO l_min_sal, l_max_sal FROM salgrade WHERE grade = p_grade;

      -- 범위 안에 p_salary의 값이 있으면 True, 그렇지 않으면 False 반환
      RETURN (p_salary >= l_min_sal) AND (p_salary <= l_max_sal);
    END sal_ok_func;

  -- 패키지 명세에서 선언한 프로시저 내용
  PROCEDURE raise_salary_proc(p_emp_id NUMBER, p_grade NUMBER, p_amount NUMBER)
  IS
    l_salary NUMBER;
    BEGIN

      -- sal정보를 저장
      SELECT sal
          INTO l_salary FROM emp WHERE empno = p_emp_id;

      -- SAL 등급을 확인하여 True이면 Update 아니면 예외발생
      IF sal_ok_func(p_grade, l_salary + p_amount)
      THEN
        UPDATE emp SET sal = sal + p_amount WHERE empno = p_emp_id;
      ELSE
        RAISE invalid_salary;
      END IF;
    END raise_salary_proc;


BEGIN

  -- 패키지 실행 시 초기화
  g_hired_cnt := 0;

END emp_info_pkg;
/

