create view VIEW_CHK20 as
  select EMPNO, ENAME, SAL, COMM, DEPTNO
    from EMP01
    where DEPTNO = 20 with check option
/

