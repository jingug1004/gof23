create view VIEW_EMP10 as
  select EMPNO, ENAME, SAL, COMM, DEPTNO
    from EMP01
    WHERE DEPTNO = 10
/

