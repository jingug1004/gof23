create view VIEW_EMP as
  select EMPNO, ENAME, SAL, DEPTNO
  from EMP01
/

