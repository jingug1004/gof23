create PACKAGE emp_info_pkg AS

  -- 타입 선언
  TYPE emprectyp IS RECORD (empno emp.empno%TYPE, ename emp.ename%TYPE, sal emp.sal%TYPE);

  -- 함수 선언
  FUNCTION get_ename_func(p_empno NUMBER)
    RETURN emprectyp;

  -- 프로시저 선언
  PROCEDURE get_dname_proc(p_deptno IN NUMBER, p_dname OUT VARCHAR2);
  PROCEDURE raise_salary_proc(p_emp_id NUMBER, p_grade NUMBER, p_amount NUMBER);

  -- 전역 변수 선언
  g_hired_cnt NUMBER;

  -- 예외 처리 변수 선언
    invalid_salary EXCEPTION;

END emp_info_pkg;
/

