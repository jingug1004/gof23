create FUNCTION get_avg_func(p_deptno NUMBER)
RETURN NUMBER 
IS

   l_result NUMBER := 0;
BEGIN

   SELECT AVG(sal)
     INTO l_result
     FROM emp
    WHERE deptno = p_deptno ;

   RETURN l_result;
END;
/

