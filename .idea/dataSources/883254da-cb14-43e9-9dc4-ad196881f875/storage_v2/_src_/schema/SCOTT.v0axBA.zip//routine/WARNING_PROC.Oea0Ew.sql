create PROCEDURE warning_proc AS
  x CONSTANT BOOLEAN := TRUE;
  l_emp_name NUMBER;
  l_sal      NUMBER;

  BEGIN
    IF x
    THEN
      DBMS_OUTPUT.PUT_LINE('TRUE');
    ELSE
      DBMS_OUTPUT.PUT_LINE('FALSE');
    END IF;

    SELECT sal INTO l_sal FROM emp WHERE ename = l_emp_name;

  END warning_proc;

  CREATE OR REPLACE PROCEDURE warning_proc AS
  x CONSTANT BOOLEAN := TRUE;

BEGIN
  IF x THEN
    DBMS_OUTPUT.PUT_LINE('TRUE');
  ELSE
    DBMS_OUTPUT.PUT_LINE('FALSE');
  END IF;

EXCEPTION
  WHEN others THEN
    DBMS_OUTPUT.PUT_LINE(SQLCODE  || SQLERRM); 
    --RAISE 생략
    --RAISE;

END warning_proc;
/

