create view VIEW_READ30 as
  select EMPNO, ENAME, SAL, COMM, DEPTNO
    from EMP01
    where DEPTNO = 30 with READ ONLY
/

