create view VIEW_NOTABLE as
  select EMPNO, ENAME, DEPTNO
    from EMP02
    WHERE DEPTNO = 10
/

