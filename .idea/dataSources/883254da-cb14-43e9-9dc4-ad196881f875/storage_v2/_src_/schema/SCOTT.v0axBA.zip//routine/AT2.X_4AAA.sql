create PROCEDURE at2
IS
  BEGIN
    -- 부모 트랜잭션에서 INSERT 수행
    INSERT INTO dept VALUES (77, 'at2', 'at2');

    -- 자율 트랜잭션으로 선언한 at1 프로시저 호출
    at1;

    -- 부모 트랜잭션 변경 사항 롤백
    ROLLBACK;

    EXCEPTION
    WHEN others
    THEN
      DBMS_OUTPUT.PUT_LINE(SQLERRM(SQLCODE));
  END;
/

