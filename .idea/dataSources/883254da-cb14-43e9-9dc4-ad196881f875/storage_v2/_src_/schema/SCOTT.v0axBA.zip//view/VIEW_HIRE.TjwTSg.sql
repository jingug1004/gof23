create view VIEW_HIRE as
  select EMPNO, ENAME, HIREDATE
    from EMP
    order by HIREDATE
/

