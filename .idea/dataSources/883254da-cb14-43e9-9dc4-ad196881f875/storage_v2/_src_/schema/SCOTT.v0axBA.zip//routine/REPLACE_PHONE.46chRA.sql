create PROCEDURE replace_phone(p_phone IN OUT VARCHAR2)
IS
  BEGIN
    p_phone := REPLACE(p_phone, '-');
  END replace_phone;
/

